"""iqview/plugins/plugin_manager.py

PluginManagerMixin — mixed into SpectrogramWindow.

Plugin contract
---------------
A plugin is a plain .py file that exposes a top-level function:

    def run(samples: np.ndarray, info: dict) -> PluginResult:
        ...

`samples`  — complex64 numpy array of IQ samples for the current view window.
`info`     — dict with keys:
               sample_rate  (Hz)
               center_freq  (Hz)
               t_start      (seconds, start of current view)
               t_end        (seconds, end of current view)
               f_start      (Hz, bottom of current view)
               f_end        (Hz, top of current view)
               overlays     (list[Overlay] — deep copies of all overlays currently
                             on screen; read-only snapshot; safe to inspect from a
                             background thread)
Return     — a PluginResult instance (from `from iqview import PluginResult`).
             Use .add(), .update(), .remove(), .replace() to express operations.
             Returning anything other than a PluginResult raises an error dialog.

Optional module-level metadata constants:
    PLUGIN_NAME               = "Human readable name"
    PLUGIN_DESCRIPTION        = "One-liner description shown in the menu tooltip"
    PLUGIN_RUN_ON_MAIN_THREAD = False  # Set to True to run synchronously (useful for matplotlib/GUI debugging)
"""

from __future__ import annotations

import copy
import importlib.util
import sys
import traceback
import uuid
from typing import Any, Dict, List, Optional

import numpy as np
from PyQt6.QtCore import QObject, QThread, pyqtSignal
from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import QFileDialog, QMessageBox, QProgressDialog


# ---------------------------------------------------------------------------
# Background worker — runs the plugin's `run()` on a QThread
# ---------------------------------------------------------------------------

class _PluginWorker(QObject):
    finished = pyqtSignal(object)  # PluginResult — passed straight through
    error    = pyqtSignal(str)     # error message string

    def __init__(self, func, samples: np.ndarray, info: dict) -> None:
        super().__init__()
        self._func    = func
        self._samples = samples
        self._info    = info

    def run(self) -> None:
        try:
            result = self._func(self._samples, self._info)
            self.finished.emit(result)
        except Exception:
            self.error.emit(traceback.format_exc())


# ---------------------------------------------------------------------------
# Mixin
# ---------------------------------------------------------------------------

class PluginManagerMixin:
    """
    Manages loading and running IQView plugins.

    Attributes added to the host class
    -----------------------------------
    _loaded_plugins  : dict[str, dict]   name → {path, module, func, description}
    _plugins_menu    : QMenu | None
    """

    # ------------------------------------------------------------------
    # Initialisation (call from SpectrogramWindow.__init__)
    # ------------------------------------------------------------------

    def _init_plugins(self) -> None:
        self._loaded_plugins: Dict[str, dict] = {}
        self._plugins_menu = None  # set by component_setup after menu is built
        self._plugin_thread: Optional[QThread] = None
        self._plugin_worker: Optional[_PluginWorker] = None
        # Restore plugins saved from a previous session
        self._load_persisted_plugins()

    # ------------------------------------------------------------------
    # Menu management
    # ------------------------------------------------------------------

    def _rebuild_plugins_menu(self) -> None:
        """Rebuild the dynamic portion of the Plugins menu."""
        menu = self._plugins_menu
        if menu is None:
            return

        menu.clear()

        # Static actions
        load_action = QAction("&Load Plugin…", self)
        load_action.setStatusTip("Load a Python plugin file (.py)")
        load_action.triggered.connect(self.load_plugin)
        menu.addAction(load_action)

        menu.addSeparator()

        unload_action = QAction("Unload &All", self)
        unload_action.setStatusTip("Remove all currently loaded plugins")
        unload_action.triggered.connect(self._unload_all_plugins)
        unload_action.setEnabled(bool(self._loaded_plugins))
        menu.addAction(unload_action)

        # Dynamic: one action per loaded plugin
        if self._loaded_plugins:
            menu.addSeparator()
            for name, info in self._loaded_plugins.items():
                action = QAction(f"▶  {name}", self)
                desc = info.get("description", "")
                tip  = f"Run plugin: {name}"
                if desc:
                    tip += f" — {desc}"
                action.setStatusTip(tip)
                action.setToolTip(tip)
                # Capture name in closure
                action.triggered.connect(
                    lambda _checked, n=name: self.run_plugin(n)
                )
                menu.addAction(action)

        if hasattr(self, 'marker_panel') and hasattr(self.marker_panel, 'update_plugins_list'):
            self.marker_panel.update_plugins_list(self._loaded_plugins)

    # ------------------------------------------------------------------
    # Load
    # ------------------------------------------------------------------

    def load_plugin(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Load Plugin", "", "Python Files (*.py)"
        )
        if not path:
            return
        self._load_plugin_from_path(path)

    def _load_plugin_from_path(self, path: str, _persist: bool = True, _silent: bool = False) -> None:
        """Dynamically import a plugin file and register it."""
        import os
        base  = os.path.splitext(os.path.basename(path))[0]
        # Use a unique module name to avoid namespace collisions with re-loads
        mod_name = f"_iqview_plugin_{base}_{uuid.uuid4().hex[:8]}"

        try:
            spec   = importlib.util.spec_from_file_location(mod_name, path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
        except Exception as exc:
            QMessageBox.critical(
                self, "Plugin Load Error",
                f"Could not load plugin from:\n{path}\n\n{exc}"
            )
            return

        if not hasattr(module, "run") or not callable(module.run):
            QMessageBox.critical(
                self, "Plugin Load Error",
                f"The file does not contain a callable `run(samples, info)` function:\n{path}"
            )
            return

        name        = getattr(module, "PLUGIN_NAME",        base)
        description = getattr(module, "PLUGIN_DESCRIPTION", "")
        run_on_main = getattr(module, "PLUGIN_RUN_ON_MAIN_THREAD", False)

        # If a plugin with the same display name is already loaded, replace it
        params_spec = getattr(module, "PLUGIN_PARAMS", {})
        active_params = {}
        if isinstance(params_spec, dict):
            for k, spec in params_spec.items():
                if isinstance(spec, dict):
                    active_params[k] = spec.get("default")
                else:
                    active_params[k] = spec

        self._loaded_plugins[name] = {
            "path":        path,
            "module":      module,
            "func":        module.run,
            "description": description,
            "run_on_main": run_on_main,
            "params_spec": params_spec,
            "params":      active_params
        }

        if _persist:
            self._save_plugin_paths()
        self._rebuild_plugins_menu()
        if not _silent:
            self.statusBar().showMessage(f"Plugin loaded: {name}", 3000)

    # ------------------------------------------------------------------
    # Unload
    # ------------------------------------------------------------------

    def unload_plugin(self, name: str) -> None:
        if name in self._loaded_plugins:
            del self._loaded_plugins[name]
            self._save_plugin_paths()
            self._rebuild_plugins_menu()
            self.statusBar().showMessage(f"Plugin unloaded: {name}", 3000)

    def _unload_all_plugins(self) -> None:
        self._loaded_plugins.clear()
        self._save_plugin_paths()
        self._rebuild_plugins_menu()
        self.statusBar().showMessage("All plugins unloaded.", 3000)

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _save_plugin_paths(self) -> None:
        """Persist current plugin file paths to settings."""
        if not hasattr(self, 'settings_mgr'):
            return
        paths = ";;".join(
            info["path"] for info in self._loaded_plugins.values()
        )
        self.settings_mgr.set("plugins/loaded_paths", paths)

    def _load_persisted_plugins(self) -> None:
        """Reload plugin files saved from the previous session."""
        if not hasattr(self, 'settings_mgr'):
            return
        raw = self.settings_mgr.get("plugins/loaded_paths", "")
        if not raw:
            return
        import os
        for path in raw.split(";;"):
            path = path.strip()
            if path and os.path.isfile(path):
                # _persist=False and _silent=True: don't re-save, don't call statusBar yet
                self._load_plugin_from_path(path, _persist=False, _silent=True)

    # ------------------------------------------------------------------
    # Run
    # ------------------------------------------------------------------

    def run_plugin(self, name: str) -> None:
        info = self._loaded_plugins.get(name)
        if info is None:
            return

        if not self._has_data():
            QMessageBox.information(
                self, "No Data",
                "Please open an IQ file before running a plugin."
            )
            return

        # Gather current view range
        try:
            xr, yr = self.spectrogram_view.plot_item.viewRange()
            t_start, t_end = xr[0], xr[1]
            f_start, f_end = yr[0], yr[1]
        except Exception:
            t_start, t_end = 0.0, self.time_duration
            f_start = self.fc - self.rate / 2
            f_end   = self.fc + self.rate / 2

        # Extract IQ samples for the visible time window
        samples = self.extract_iq_segment(t_start, t_end)
        if samples is None or len(samples) == 0:
            QMessageBox.warning(
                self, "Plugin Error",
                "Could not extract IQ samples for the current view.\n"
                "Make sure a file is loaded and the view contains data."
            )
            return

        context = {
            "sample_rate": self.rate,
            "center_freq": self.fc,
            "t_start":     t_start,
            "t_end":       t_end,
            "f_start":     f_start,
            "f_end":       f_end,
            # Deep copies — the background thread gets a safe, immutable snapshot.
            # Plugins can read .id, .shape, .points etc. directly on these objects.
            "overlays":    [copy.deepcopy(o) for o in self.overlays],
            "params":      copy.deepcopy(info.get("params", {})),
        }

        # Run synchronously on main thread if requested (for GUI/matplotlib debugging)
        if info.get("run_on_main", False):
            try:
                result = info["func"](samples, context)
                self._on_plugin_finished(name, result)
            except Exception:
                self._on_plugin_error(name, traceback.format_exc())
            return

        # Otherwise, run on background thread
        self._run_plugin_async(name, info["func"], samples, context)

    def _run_plugin_async(
        self,
        name:    str,
        func,
        samples: np.ndarray,
        info:    dict,
    ) -> None:
        # Guard: don't start a second plugin while one is running
        if self._plugin_thread is not None:
            try:
                running = self._plugin_thread.isRunning()
            except RuntimeError:
                running = False      # C++ object already deleted
                self._plugin_thread = None
            if running:
                QMessageBox.information(
                    self, "Plugin Busy",
                    "A plugin is already running. Please wait for it to finish."
                )
                return

        # Progress dialog (indeterminate)
        self._plugin_progress = QProgressDialog(
            f"Running plugin: {name}…", "Cancel", 0, 0, self
        )
        self._plugin_progress.setWindowTitle("Plugin")
        self._plugin_progress.setMinimumDuration(300)
        self._plugin_progress.setModal(True)

        worker = _PluginWorker(func, samples, info)
        thread = QThread(self)
        worker.moveToThread(thread)

        thread.started.connect(worker.run)
        worker.finished.connect(lambda result, n=name: self._on_plugin_finished(n, result))
        worker.error.connect(lambda msg, n=name: self._on_plugin_error(n, msg))
        worker.finished.connect(thread.quit)
        worker.error.connect(thread.quit)

        # Clear our reference BEFORE deleteLater fires, so a subsequent
        # isRunning() check never touches a deleted C++ object.
        def _clear_thread():
            self._plugin_thread = None
            self._plugin_worker = None

        thread.finished.connect(_clear_thread)
        thread.finished.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(self._plugin_progress.close)

        self._plugin_progress.canceled.connect(thread.requestInterruption)

        self._plugin_thread = thread
        self._plugin_worker = worker
        thread.start()

    def _on_plugin_finished(self, name: str, result: object) -> None:
        """Called on the main thread when a plugin completes successfully."""
        from iqview.plugins.plugin_result import PluginResult

        if not isinstance(result, PluginResult):
            QMessageBox.critical(
                self, f"Plugin Error — {name}",
                f"Plugin '{name}' did not return a PluginResult object.\n\n"
                f"Got: {type(result).__name__}\n\n"
                f"Make sure your run() function returns a PluginResult:\n"
                f"    from iqview import PluginResult\n"
                f"    def run(samples, info):\n"
                f"        result = PluginResult()\n"
                f"        ...\n"
                f"        return result"
            )
            return

        plugin_source = f"plugin:{name}"
        n_added = n_updated = n_removed = n_replaced = 0

        # 1. Removes — source-restricted: only overlays this plugin owns
        for oid in result._removes:
            existing = self._get_overlay_by_id(oid)
            if existing is None:
                print(f"[IQView Plugin] remove: overlay {oid!r} not found, skipping.")
                continue
            if existing.source != plugin_source:
                print(
                    f"[IQView Plugin] remove: overlay {oid!r} is owned by "
                    f"{existing.source!r}, not {plugin_source!r} — skipping."
                )
                continue
            self.remove_overlay(oid)
            n_removed += 1

        # 2. Replaces — remove old, add new (inheriting original source)
        for old_id, new_overlay in result._replaces:
            original = self._get_overlay_by_id(old_id)
            original_source = original.source if original is not None else plugin_source
            if original is not None:
                self.remove_overlay(old_id)
            new_overlay.id     = str(uuid.uuid4())
            new_overlay.source = original_source   # preserve provenance
            self.add_overlay(new_overlay)
            n_replaced += 1

        # 3. Updates — patch fields on existing overlays
        for oid, fields in result._updates:
            existing = self._get_overlay_by_id(oid)
            if existing is None:
                print(f"[IQView Plugin] update: overlay {oid!r} not found, skipping.")
                continue
            self.update_overlay(oid, **fields)
            n_updated += 1

        # 4. Adds — always allowed; fresh UUID + plugin source
        for overlay in result._adds:
            try:
                overlay.id     = str(uuid.uuid4())
                overlay.source = plugin_source
                self.add_overlay(overlay)
                n_added += 1
            except Exception as exc:
                print(f"[IQView Plugin] add: skipping malformed overlay: {exc}")

        self.statusBar().showMessage(
            f"Plugin '{name}' — "
            f"{n_added} added, {n_updated} updated, "
            f"{n_removed} removed, {n_replaced} replaced.",
            4000,
        )

        # Switch to OVERLAY mode so the user immediately sees the results
        any_change = n_added + n_updated + n_removed + n_replaced
        if any_change > 0 and hasattr(self, 'set_interaction_mode'):
            self.set_interaction_mode('OVERLAY')

    def _on_plugin_error(self, name: str, msg: str) -> None:
        QMessageBox.critical(
            self, f"Plugin Error — {name}",
            f"The plugin raised an exception:\n\n{msg}"
        )
