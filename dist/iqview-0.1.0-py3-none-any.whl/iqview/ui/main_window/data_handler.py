import numpy as np
from PyQt6.QtCore import pyqtSlot
from iqview.dsp import FileReaderThread

class DataHandlerMixin:
    def start_processing(self):
        if hasattr(self, 'worker') and self.worker.isRunning():
            self.worker.stop()
        self.progress_bar.setValue(0)
        self.progress_bar.setStyleSheet("QProgressBar { background-color: transparent; border: none; } QProgressBar::chunk { background-color: #00aaff; }")
        self.worker = FileReaderThread(self.file_path, self.data_type, self.fft_size, self.overlap_percent, self.rate, self.profile_enabled, self.window_type)
        self.worker.progress.connect(self.update_progress)
        self.worker.finished_processing.connect(self.display_spectrogram)
        self.worker.start()

    @pyqtSlot(int, int)
    def update_progress(self, current, total):
        self.progress_bar.setMaximum(total)
        self.progress_bar.setValue(current)

    @pyqtSlot(np.ndarray, float)
    def display_spectrogram(self, full_spectrogram, duration):
        self.progress_bar.setValue(0)
        self.progress_bar.setStyleSheet("QProgressBar { background-color: transparent; border: none; } QProgressBar::chunk { background-color: transparent; }")
        self.full_spectrogram_cache = full_spectrogram
        self.time_duration = duration
        self.total_samples_in_cache = int(round(duration * self.rate))
        self.spectrogram_view.update_spectrogram(full_spectrogram, self.fc, self.rate, self.time_duration, auto_range=self.is_first_load)
        self.is_first_load = False
        self.update_marker_info()

    def extract_iq_segment(self, start_sec, end_sec):
        """
        Extracts raw complex IQ samples from the file for a given time range.
        """
        try:
            start_sample = int(round(start_sec * self.rate))
            end_sample = int(round(end_sec * self.rate))
            if start_sample > end_sample: start_sample, end_sample = end_sample, start_sample
            
            num_samples = end_sample - start_sample
            if num_samples <= 0: return None
            
            # Cap extraction for performance
            MAX_EXTRACT_SAMPLES = 1_000_000
            if num_samples > MAX_EXTRACT_SAMPLES:
                num_samples = MAX_EXTRACT_SAMPLES
                end_sample = start_sample + num_samples

            item_size = np.dtype(self.data_type).itemsize
            offset = start_sample * 2 * item_size # 2 for I/Q
            
            # Use np.fromfile to read specific chunk
            with open(self.file_path, 'rb') as f:
                f.seek(offset)
                raw_data = np.fromfile(f, dtype=self.data_type, count=num_samples * 2)
                
            complex_data = raw_data[0::2].astype(np.float32) + 1j * raw_data[1::2].astype(np.float32)
            return complex_data
        except Exception as e:
            print(f"Error extracting IQ segment: {e}")
            return None
